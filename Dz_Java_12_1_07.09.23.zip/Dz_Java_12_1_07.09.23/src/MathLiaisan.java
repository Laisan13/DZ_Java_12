import java.util.Arrays;

public  class MathLiaisan {

    private MathLiaisan() {
    }


    public static int addAll(int... numbers) {
        int result = 0;
        for (int number : numbers) {
            result += number;
        }

        return result;
    }


    public static int minusAll(int original, int... numbers) {
        int result = 0;
        for (int number : numbers) {
            result = original - number;
        }

        return result;
    }

    public static int multAll(int... numbers) {
        int mult = 1;
        for (int number : numbers) {
            mult *= number;
        }

        return mult;
    }
    public static int pow(int value, int powValue) {
        int result = 1;
        for (int i = 1; i <= powValue; i++) {
            result = result * value;
        }
        return result;
    }

    public static int powAll(int baza, int... numbers) {
        int result =  baza;
        if (numbers.length == 0) {
            return 1;
        }
        else {
            for (int i = 0; i < numbers.length; i++) {
                result = pow(result, numbers[i]);
            }

        }
        return result;

    }

}








import car.*;

import java.awt.*;
import java.util.Arrays;


public class Main {
    public static void main(String[] args) {
//        Напишите класс Автомобиль с минимум пятью полями. Переопределите метод toString,
//        чтобы он выводил полное описание автомобиля по его полям.
//        В программе создайте 3 разных автомобиля и выведите каждый из них в консоль.
//        Создайте массив из этих автомобилей. С помощью Arrays.toString()
//        превратите массив в строку и выведите в консоль.
//        Перейдите в код метода Arrays.toString() и посмотрите на его реализацию.
//        В какой момент автомобиль становится строкой внутри этого метода?


                Car auto1 = new Car(Plant.FORD_KANSAS_CITY,TypeBody.COUPE,2018,3f,Color.BLACK);
        System.out.println(auto1);
        Car auto2 = new Car(Plant.HYUNDAI_ULSAN,TypeBody.CARGO_VAN,2021,2.6f,Color.red);
        System.out.println(auto2);
        Car auto3 = new Car(Plant.AVTO_VAZ,TypeBody.HATCHBACK,2022,2f,Color.blue);
        System.out.println(auto3);

        Car[][] cars = {{auto1},{auto2},{auto3}};
        System.out.println(Arrays.toString(cars));
        // Если массив содержит другие массивы в качестве элементов,
        // они преобразуются в строки методом Object.toString, унаследованным от Object,
        // который описывает их идентификаторы, а не содержимое.



    }

}
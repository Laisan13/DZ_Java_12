package car;

import java.awt.*;

public class Car {
    private Plant manufacturer;
    private TypeBody typeBody;//типы кузова
    private int year;// год выпуска
    private float engineDisplacement; //объем двигателя 1–1,2 литра; 1,2–1,6 литра; 1,6–2 литра; 2–2,5 литра; от 2 л и больше.
    private Color color;

    public Plant getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(Plant manufacturer) {
        this.manufacturer = manufacturer;
    }

    public TypeBody getTypeBody() {
        return typeBody;
    }

    public void setTypeBody(TypeBody typeBody) {
        this.typeBody = typeBody;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public float getEngineDisplacement() {
        return engineDisplacement;
    }

    public void setEngineDisplacement(float engineDisplacement) {
        this.engineDisplacement = engineDisplacement;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Car(Plant manufacturer, TypeBody typeBody, int year, float engineDisplacement, Color color) {
        this.manufacturer = manufacturer;
        this.typeBody = typeBody;
        this.year = year;
        this.engineDisplacement = engineDisplacement;
        this.color = color;
    }



    @Override
    public String toString() {
        return "Car{" +
                "manufacturer=" + manufacturer +
                ", typeBody=" + typeBody +
                ", year=" + year +
                ", engineDisplacement=" + engineDisplacement +
                ", color=" + color +
                '}';
    }

    public Car(){

    }






}






